module.exports = {
    mysql: {
        host: '127.0.0.1',
        user: 'root', //你的数据库账号
        password: 'root', //你的数据库密码
        database: 'expressdb',//你的数据库名
        port: 3306
    }
}